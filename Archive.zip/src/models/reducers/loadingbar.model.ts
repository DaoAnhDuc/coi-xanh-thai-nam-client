export interface ILoadingBar {
  show: boolean
}
export const defaultLoadingBar: ILoadingBar = { show: false }

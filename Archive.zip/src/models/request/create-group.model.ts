export interface ICreateGroup {
  name: string;
  projects?: Array<string>;
}

export interface IPostRegister {
  fullname: string;
  username: string;
  email: string;
  password: string;
  repassword: string;
  rememberMe: boolean;
}

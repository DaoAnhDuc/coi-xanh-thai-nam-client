export interface IPostLogin {
  userName: string
  password: string
  rememberMe: boolean
}

import {} from 'react';
import { Navigation } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import { chunkArray } from '.';
type Props = {};

const SanPhamBanChay = ({}: Props) => {
  const data = [
    {
      img: './images/./product/sp9.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp10.png',

      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp11.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp12.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp13.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp14.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp1.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp1.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp1.png',

      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
    {
      img: './images/./product/sp1.png',
      name: 'Bàn Khảm Trai Cao Cấp : ms 001',
    },
  ];
  return (
    <div className="mt-12 mb-12">
      <div className="container">
        <div
          className="text-white"
          style={{ borderBottom: '3px solid var(--green)' }}
        >
          <div
            className="w-fit text-xl px-6 py-1"
            style={{ background: 'var(--green)' }}
          >
            Sản phẩm bán chạy
          </div>
        </div>
        <Swiper navigation={true} modules={[Navigation]} className="mt-1">
          {chunkArray(data, 5).map((arr: any[], index: number) => (
            <SwiperSlide key={index} className="relative">
              <div className="grid grid-cols-5 gap-4" key={index}>
                {arr.map((item, idx) => (
                  <div
                    className="relative "
                    key={idx}
                    style={{ border: '1px solid #dfdfdf' }}
                  >
                    <div
                      className="absolute top-3 right-3 w-12 h-12 text-white rounded-full flex justify-center items-center"
                      style={{ background: 'var(--green)' }}
                    >
                      {item.sale}
                    </div>
                    <img src={item.img} alt="" className="w-full" />
                    <div className="px-2 py-1">
                      <p className="line-clamp-2 text-center">{item.name}</p>
                    </div>
                    <div className="flex justify-center  items-center gap-4 pb-4"></div>
                  </div>
                ))}
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default SanPhamBanChay;
